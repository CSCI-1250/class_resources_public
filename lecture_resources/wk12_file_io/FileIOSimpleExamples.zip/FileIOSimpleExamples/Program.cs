using System;

namespace FileIOSimpleExamples
{
    class Program
    {
        private static string _workingDirectory = "test_files";
        private static string _sampleFilePath;
        private static string _sampleDirPath;

        static void Main(string[] args)
        {
            // Initialize paths
            _sampleFilePath = System.IO.Path.Combine(_workingDirectory, "sample.txt");
            _sampleDirPath = System.IO.Path.Combine(_workingDirectory, "sample_dir");
            
            // Ensure working directory exists
            if (!System.IO.Directory.Exists(_workingDirectory))
            {
                System.IO.Directory.CreateDirectory(_workingDirectory);
                Console.WriteLine($"Created working directory: {_workingDirectory}");
            }

            bool exit = false;
            
            while (!exit)
            {
                DisplayMenu();
                
                Console.Write("\nEnter your choice (1-11): ");
                string input = Console.ReadLine();
                
                if (int.TryParse(input, out int choice))
                {
                    Console.Clear();
                    Console.WriteLine($"Selected: {GetMenuOptionName(choice)}\n");
                    
                    switch (choice)
                    {
                        case 1:
                            TestReadTextFile();
                            break;
                        case 2:
                            TestWriteTextFile();
                            break;
                        case 3:
                            TestFileExists();
                            break;
                        case 4:
                            TestStreamWrite();
                            break;
                        case 5:
                            TestStreamRead();
                            break;
                        case 6:
                            TestDirectoryOperations();
                            break;
                        case 7:
                            TestPathOperations();
                            break;
                        case 8:
                            TestBinaryFileOperations();
                            break;
                        case 9:
                            TestBinaryReaderWriter();
                            break;
                        case 10:
                            TestSafeFileOperations();
                            break;
                        case 11:
                            exit = true;
                            Console.WriteLine("Exiting program. Goodbye!");
                            continue;
                        default:
                            Console.WriteLine("Invalid choice. Please try again.");
                            break;
                    }
                }
                else
                {
                    Console.WriteLine("Invalid input. Please enter a number between 1 and 11.");
                }
                
                Console.WriteLine("\nPress any key to continue...");
                Console.ReadKey();
                Console.Clear();
            }
        }
        
        static void DisplayMenu()
        {
            Console.WriteLine("===== File I/O Examples Menu =====");
            Console.WriteLine("1. Read Text File");
            Console.WriteLine("2. Write Text File");
            Console.WriteLine("3. Check File Exists");
            Console.WriteLine("4. Stream Write Example");
            Console.WriteLine("5. Stream Read Example");
            Console.WriteLine("6. Directory Operations");
            Console.WriteLine("7. Path Operations");
            Console.WriteLine("8. Binary File Operations");
            Console.WriteLine("9. Binary Reader/Writer Example");
            Console.WriteLine("10. Safe File Operations");
            Console.WriteLine("11. Exit");
        }
        
        static string GetMenuOptionName(int option)
        {
            return option switch
            {
                1 => "Read Text File",
                2 => "Write Text File",
                3 => "Check File Exists",
                4 => "Stream Write Example",
                5 => "Stream Read Example",
                6 => "Directory Operations",
                7 => "Path Operations",
                8 => "Binary File Operations",
                9 => "Binary Reader/Writer Example",
                10 => "Safe File Operations",
                11 => "Exit",
                _ => "Unknown Option"
            };
        }
        
        static void TestReadTextFile()
        {
            Console.WriteLine("Testing ReadTextFile()...");
            Console.WriteLine($" - Path: {_sampleFilePath}");
            
            // Create a sample file to read
            string content = "This is line 1.\nThis is line 2.\nThis is line 3.";
            System.IO.File.WriteAllText(_sampleFilePath, content);
            Console.WriteLine($"Created sample file at {_sampleFilePath}");
            
            // Call the method
            SimpleExamples.ReadTextFile(_sampleFilePath);
        }
        
        static void TestWriteTextFile()
        {
            Console.WriteLine("Testing WriteTextFile()...");
            Console.WriteLine($" - Path: {_sampleFilePath}");
            Console.Write("Enter content to write to file: ");
            string content = Console.ReadLine() ?? "Default content";
            
            SimpleExamples.WriteTextFile(_sampleFilePath, content);
            
            Console.WriteLine("\nFile content after operation:");
            Console.WriteLine(System.IO.File.ReadAllText(_sampleFilePath));
        }
        
        static void TestFileExists()
        {
            Console.WriteLine("Testing FileExists()...");
            
            // Test with existing file
            if (!System.IO.File.Exists(_sampleFilePath))
            {
                System.IO.File.WriteAllText(_sampleFilePath, "Sample content");
                Console.WriteLine($"Created sample file for testing: {_sampleFilePath}");
            }
            
            SimpleExamples.FileExists(_sampleFilePath);
            
            // Test with non-existent file
            string nonExistentFile = System.IO.Path.Combine(_workingDirectory, "does_not_exist.txt");
            SimpleExamples.FileExists(nonExistentFile);
        }
        
        static void TestStreamWrite()
        {
            Console.WriteLine("Testing StreamWriteExample()...");
            SimpleExamples.StreamWriteExample(_sampleFilePath);
            
            Console.WriteLine("\nFile content after operation:");
            Console.WriteLine(System.IO.File.ReadAllText(_sampleFilePath));
        }
        
        static void TestStreamRead()
        {
            Console.WriteLine("Testing StreamReadExample()...");
            
            // Make sure we have a file to read
            if (!System.IO.File.Exists(_sampleFilePath))
            {
                string content = "Line 1 for stream test\nLine 2 for stream test\nLine 3 for stream test";
                System.IO.File.WriteAllText(_sampleFilePath, content);
                Console.WriteLine($"Created sample file for testing: {_sampleFilePath}");
            }
            
            SimpleExamples.StreamReadExample(_sampleFilePath);
        }
        
        static void TestDirectoryOperations()
        {
            Console.WriteLine("Testing DirectoryExample()...");
            
            // Create some files in the directory for testing
            if (!System.IO.Directory.Exists(_sampleDirPath))
            {
                System.IO.Directory.CreateDirectory(_sampleDirPath);
            }
            
            string file1 = System.IO.Path.Combine(_sampleDirPath, "file1.txt");
            string file2 = System.IO.Path.Combine(_sampleDirPath, "file2.txt");
            string subdir = System.IO.Path.Combine(_sampleDirPath, "subdir");

            Console.WriteLine($" - Directory: {_sampleDirPath}");
            Console.WriteLine($" - File 1: {file1}");
            Console.WriteLine($" - File 2: {file2}");
            Console.WriteLine($" - Subdir: {subdir}");
            
            System.IO.File.WriteAllText(file1, "Content for file 1");
            System.IO.File.WriteAllText(file2, "Content for file 2");
            
            if (!System.IO.Directory.Exists(subdir))
            {
                System.IO.Directory.CreateDirectory(subdir);
            }
            
            Console.WriteLine($"Created sample files and subdirectory in {_sampleDirPath}");
            
            SimpleExamples.DirectoryExample(_sampleDirPath);
        }
        
        static void TestPathOperations()
        {
            Console.WriteLine("Testing PathExample()...");
            SimpleExamples.PathExample();
        }
        
        static void TestBinaryFileOperations()
        {
            Console.WriteLine("Testing BinaryFileExample()...");
            string binaryFilePath = System.IO.Path.Combine(_workingDirectory, "binary_sample.bin");

            Console.WriteLine($" - Directory: {_workingDirectory}");
            Console.WriteLine($" - File path: {binaryFilePath}");
            
            SimpleExamples.BinaryFileExample(binaryFilePath);
        }
        
        static void TestBinaryReaderWriter()
        {
            Console.WriteLine("Testing BinaryReaderWriterExample()...");
            string binaryFilePath = System.IO.Path.Combine(_workingDirectory, "mixed_data.bin");

            Console.WriteLine($" - Directory: {_workingDirectory}");
            Console.WriteLine($" - File path: {binaryFilePath}");
            
            SimpleExamples.BinaryReaderWriterExample(binaryFilePath);
        }
        
        static void TestSafeFileOperations()
        {
            Console.WriteLine("Testing SafeFileOperations()...");
            string testFilePath = System.IO.Path.Combine(_workingDirectory, "safe_test.txt");
            
            Console.WriteLine($" - Directory: {_workingDirectory}");
            Console.WriteLine($" - File path: {testFilePath}");

            SimpleExamples.SafeFileOperations(testFilePath);
            
            // Test with a file that might cause permission issues
            Console.WriteLine("\nTesting with potential permission issues:");
            try
            {
                SimpleExamples.SafeFileOperations(@"C:\Windows\System32\test.txt");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Expected error occurred: {ex.Message}");
            }
        }
    }
}
