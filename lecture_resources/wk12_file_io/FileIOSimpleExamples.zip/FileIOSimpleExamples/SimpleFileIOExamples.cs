using System;
using System.IO;

namespace FileIOSimpleExamples
{
    public class SimpleExamples
    {
        // Example 1: Reading a text file
        public static void ReadTextFile(string filePath)
        {
            // Read entire file at once
            string content = File.ReadAllText(filePath);
            Console.WriteLine($"File content:\n{content}");
            
            // Read line by line
            string[] lines = File.ReadAllLines(filePath);
            Console.WriteLine($"The file has {lines.Length} lines.");
            
            // First line
            if (lines.Length > 0)
                Console.WriteLine($"First line: {lines[0]}");
        }
        
        // Example 2: Writing a text file
        public static void WriteTextFile(string filePath, string content)
        {
            // Write entire content at once
            File.WriteAllText(filePath, content);
            Console.WriteLine($"File written to {filePath}");
            
            // Append to file
            File.AppendAllText(filePath, "\nThis line was appended.");
            Console.WriteLine("File appended");
        }
        
        // Example 3: Checking if file exists
        public static void FileExists(string filePath)
        {
            if (File.Exists(filePath))
            {
                Console.WriteLine($"File {filePath} exists.");
                
                // Get file info
                FileInfo fileInfo = new FileInfo(filePath);
                Console.WriteLine($"Size: {fileInfo.Length} bytes");
                Console.WriteLine($"Created: {fileInfo.CreationTime}");
                Console.WriteLine($"Last modified: {fileInfo.LastWriteTime}");
            }
            else
            {
                Console.WriteLine($"File {filePath} does not exist.");
            }
        }
        
        // Example 4: File stream writing (efficient)
        public static void StreamWriteExample(string filePath)
        {
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("Line 1");
                writer.WriteLine("Line 2");
                writer.WriteLine("Line 3");
            }
            Console.WriteLine($"Wrote 3 lines to {filePath}");
        }
        
        // Example 5: File stream reading (efficient)
        public static void StreamReadExample(string filePath)
        {
            using (StreamReader reader = new StreamReader(filePath))
            {
                int lineNumber = 1;
                string line;
                
                while ((line = reader.ReadLine()) != null)
                {
                    Console.WriteLine($"Line {lineNumber++}: {line}");
                }
            }
        }
        
        // Example 6: Directory operations
        public static void DirectoryExample(string directoryPath)
        {
            // Create directory if it doesn't exist
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
                Console.WriteLine($"Created directory: {directoryPath}");
            }
            
            // List files in directory
            string[] files = Directory.GetFiles(directoryPath);
            Console.WriteLine($"Files in {directoryPath}:");
            foreach (string file in files)
            {
                Console.WriteLine($"  {Path.GetFileName(file)}");
            }
            
            // List subdirectories
            string[] subdirs = Directory.GetDirectories(directoryPath);
            Console.WriteLine($"Subdirectories in {directoryPath}:");
            foreach (string dir in subdirs)
            {
                Console.WriteLine($"  {Path.GetFileName(dir)}");
            }
        }
        
        // Example 7: Path operations
        public static void PathExample()
        {
            string filePath = @"C:\Users\student\documents\report.docx";
            
            Console.WriteLine($"File name: {Path.GetFileName(filePath)}");
            Console.WriteLine($"Extension: {Path.GetExtension(filePath)}");
            Console.WriteLine($"Without extension: {Path.GetFileNameWithoutExtension(filePath)}");
            Console.WriteLine($"Directory: {Path.GetDirectoryName(filePath)}");
            
            // Combine paths (cross-platform)
            string newPath = Path.Combine("data", "reports", "summary.txt");
            Console.WriteLine($"Combined path: {newPath}");
        }
        
        // Example 8: Binary file operations
        public static void BinaryFileExample(string filePath)
        {
            // Create sample data
            byte[] data = new byte[10];
            for (int i = 0; i < data.Length; i++)
            {
                data[i] = (byte)(i * 10);
            }
            
            // Write binary data
            File.WriteAllBytes(filePath, data);
            Console.WriteLine($"Wrote {data.Length} bytes to {filePath}");
            
            // Read binary data
            byte[] readData = File.ReadAllBytes(filePath);
            Console.WriteLine($"Read {readData.Length} bytes from {filePath}:");
            for (int i = 0; i < readData.Length; i++)
            {
                Console.Write($"{readData[i]} ");
            }
            Console.WriteLine();
        }
        
        // Example 9: Using BinaryReader/BinaryWriter
        public static void BinaryReaderWriterExample(string filePath)
        {
            // Write data using BinaryWriter
            using (FileStream fs = new FileStream(filePath, FileMode.Create))
            using (BinaryWriter writer = new BinaryWriter(fs))
            {
                writer.Write(42);              // Write an integer
                writer.Write(3.14159);         // Write a double
                writer.Write("Hello, world!"); // Write a string
                writer.Write(true);            // Write a boolean
            }
            Console.WriteLine($"Wrote mixed data types to {filePath}");
            
            // Read data using BinaryReader
            using (FileStream fs = new FileStream(filePath, FileMode.Open))
            using (BinaryReader reader = new BinaryReader(fs))
            {
                int intValue = reader.ReadInt32();
                double doubleValue = reader.ReadDouble();
                string stringValue = reader.ReadString();
                bool boolValue = reader.ReadBoolean();
                
                Console.WriteLine($"Read values: {intValue}, {doubleValue}, {stringValue}, {boolValue}");
            }
        }
        
        // Example 10: Exception handling
        public static void SafeFileOperations(string filePath)
        {
            try
            {
                // Attempt file operations
                string content = "This is a test.";
                File.WriteAllText(filePath, content);
                
                string readBack = File.ReadAllText(filePath);
                Console.WriteLine($"Successfully read: {readBack}");
                
                // Clean up
                File.Delete(filePath);
                Console.WriteLine($"Successfully deleted {filePath}");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine($"Error: File not found. {ex.Message}");
            }
            catch (IOException ex)
            {
                Console.WriteLine($"I/O Error: {ex.Message}");
            }
            catch (UnauthorizedAccessException ex)
            {
                Console.WriteLine($"Access denied: {ex.Message}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Unexpected error: {ex.Message}");
            }
        }
    }
}
